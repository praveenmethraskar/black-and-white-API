import path from "path"
import { scopePerRequest, loadControllers } from "awilix-express"
import { MongoManager } from "../utils/mongo"

import { createContainer, asClass } from 'awilix'

import { interceptor } from "./response"

import { AppCryptoService } from "../services/crypto"
import { Application } from "express"
import { AppEnvService } from "../services/env"
import { AppConfig } from "./config"
import { Logger, AppLogger } from "./logger"
import { AppAuthMiddleware } from "./middleware"
import { AppUserRepository } from "../repository/user"
import { UserService } from "../services/user"
import { UserController } from "../controllers/user"

export const loadContainer = (app: Application) => {
    const Container = createContainer({
        injectionMode: 'CLASSIC'
    })

    Container.register({
        envService: asClass(AppEnvService).singleton(),
        logger: asClass(AppLogger).singleton().inject(() => ({
            sensitiveFields: [
                "password",
                "phone",
                "email",
                "receiverMobile",
                "name",
                "username",
                "token",
                "paymentInfo",
                "bluetoothMacId"
            ]
        })),

        appConfig: asClass(AppConfig).singleton(),
        mongoManager: asClass(MongoManager).singleton(),

        authMiddleware: asClass(AppAuthMiddleware).singleton(),

        userRepository: asClass(AppUserRepository).scoped(),
        cryptoService: asClass(AppCryptoService).scoped(),

        // Register service and controller so awilix-express can inject them into routes
        userService: asClass(UserService).scoped(),
        userController: asClass(UserController).scoped(),
    })

    const logger = Container.resolve<Logger>("logger")

    app.use(logger.contextMiddleware.bind(logger))

    app.use(logger.logRequestAndResponse.bind(logger))

    app.use(scopePerRequest(Container))

    // Fix: cwd must be project root, not src/utils (__dirname here)
    app.use(loadControllers('../routes/**/*.*s', { cwd: __dirname }))

    // Always call this when upon starthing the server so the db will be connected automatically
    Container.resolve<MongoManager>('mongoManager')

    app.use(interceptor)

    const appConfig = Container.resolve<AppConfig>("appConfig")
    if (appConfig.isTesting) {
        app.listen(0, () => { })
    } else {
        const port = process.env.PORT || 3000
        app.listen(port, () => {
            logger.info(`Server now listening at localhost:${port}`)
            Container.resolve<MongoManager>('mongoManager')
        })
    }
}